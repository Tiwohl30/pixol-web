<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nombre = $_POST["nombre"];
  $telefono = $_POST["telefono"];
  $email = $_POST["email"];
  $mensaje = $_POST["mensaje"];

  $to = "pixolfilms@gmail.com";
  $subject = "Mensaje desde el formulario de contacto";
  $message = "Nombre: $nombre\nTeléfono: $telefono\nEmail: $email\nMensaje: $mensaje";

  if (mail($to, $subject, $message)) {
    echo "El correo se envió con éxito.";
  } else {
    echo "Hubo un error al enviar el correo.";
  }
}
?>
